//
//  BlogPostViewController.swift
//  MobileUIKit
//
//  Created by Pin Truong on 14/04/2022.
//

import UIKit

class BlogPostViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }


}
