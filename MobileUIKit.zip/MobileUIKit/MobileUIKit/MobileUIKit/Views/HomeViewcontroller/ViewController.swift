//
//  ViewController.swift
//  MobileUIKit
//
//  Created by Pin Truong on 14/04/2022.
//

import UIKit
import SwiftUI
class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

/*struct ViewController_Previews: PreviewProvider {
    static var previews: some View {
         {
            ViewController()
        }
    }
}
*/
